<?php

class Eventr_Widget extends WP_Widget {

	/**
	 * Register widget with WordPress.
	 */
	function __construct() {
		parent::__construct(
			'eventr_widget', // Base ID
			esc_html__( 'Eventr', 'eventr_domain' ), // Name
			array( 'description' => esc_html__( 'Create an event', 'eventr_domain' ), ) // Args
		);
	}

	/**
	 * Front-end display of widget.
	 *
	 * @see WP_Widget::widget()
	 *
	 * @param array $args     Widget arguments.
	 * @param array $instance Saved values from database.
	 */
	public function widget( $args, $instance ) {
		echo $args['before_widget'];
		if ( ! empty( $instance['title'] ) ) {
			echo $args['before_title'] . apply_filters( 'widget_title', $instance['title'] ) . $args['after_title'];
		}
        
        echo 'title: '.$instance['title'].'<br>description: '.$instance['description'];

		echo $args['after_widget'];
	}

	/**
	 * Back-end widget form.
	 *
	 * @see WP_Widget::form()
	 *
	 * @param array $instance Previously saved values from database.
	 */
	public function form( $instance ) {
		$title = ! empty( $instance['title'] ) ? $instance['title'] : esc_html__( 'Eventr', 'eventr_domain' );
		$description = ! empty( $instance['description'] ) ? $instance['description'] : esc_html__( 'Input description here', 'eventr_domain' );
		?>
		<!-- Title -->
		<p>
            <label for="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>">
                <?php esc_attr_e( 'Title:', 'eventr_domain' ); ?>
            </label>
            <input 
                class="widefat" 
                id="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>" 
                name="<?php echo esc_attr( $this->get_field_name( 'title' ) ); ?>" 
                type="text" 
				placeholder="Title"
                value="<?php echo esc_attr( $title ); ?>"
            />
		</p>
		<!-- Image -->
		<p>
			<img id="eventr-image-picker" width="100" height="100"/>
			<script>
				document.addEventListener('DOMContentLoaded', () => {
					const element = document.querySelector('#eventr-image-picker')
					let customMedia = true
					let orig_send_attachment = wp.media.editor.send.attachment
					element.addEventListener('click', () => {
						// wp.media.editor.send.attachment = (props, attachment) => {
						// 	if (customMedia) {
						// 		element.setAttribute('src', attachment.url)
						// 	} else {
						// 		return orig_send_attachment.apply(element, [props, attachment]);
						// 	}
						// }	
						wp.media.editor.open(element);
					})
				})
			</script>
		</p>

		<!-- Description -->
		<p>
            <label for="<?php echo esc_attr( $this->get_field_id( 'description' ) ); ?>">
                <?php esc_attr_e( 'Title:', 'eventr_domain' ); ?>
            </label>
            <textarea 
                class="widefat" 
                id="<?php echo esc_attr( $this->get_field_id( 'description' ) ); ?>"
                name="<?php echo esc_attr( $this->get_field_name( 'description' ) ); ?>"
				placeholder="Description"
            >
				<?php echo $description; ?>
			</textarea>
		</p>
		<?php 
	}

	/**
	 * Sanitize widget form values as they are saved.
	 *
	 * @see WP_Widget::update()
	 *
	 * @param array $new_instance Values just sent to be saved.
	 * @param array $old_instance Previously saved values from database.
	 *
	 * @return array Updated safe values to be saved.
	 */
	public function update( $new_instance, $old_instance ) {
		$instance = array();
		$instance['title'] = ( ! empty( $new_instance['title'] ) ) ? sanitize_text_field( $new_instance['title'] ) : '';
		$instance['description'] = ( ! empty( $new_instance['description'] ) ) ? sanitize_text_field( $new_instance['description'] ) : '';

		return $instance;
	}

}

?>