<?php

    class EventrIcons {
        public function okay($color) {
            ?>
            <svg version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
                viewBox="0 0 214.155 214.155" xml:space="preserve" width="100" height="100">
            <path d="M74.551,193.448L0,118.896l33.136-33.135l41.415,41.415L181.02,20.707l33.135,33.136L74.551,193.448z" fill="<?php echo $color; ?>" />
            </svg>
            <?php
        }
    }

?>
